<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */


// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'This script cannot be accessed directly.' );
}

?>

<div class="clplace-social-share-wrapper">
Social Share
</div>
